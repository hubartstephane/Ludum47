
#pragma once

#if 0

// Free sounds
https://freesound.org/

// Pixel Art editing online
https://www.piskelapp.com/

// working with GIF's online (cut, crop, skip frame ...)
https://ezgif.com/

// making seamless texture online
https://www.imgonline.com.ua/eng/make-seamless-texture.php

// Voice generation
https://www.naturalreaders.com/online/

// music utility
https://boscaceoil.net/

// benchmark C++ online
https://quick-bench.com/

// compiler explorer online
https://godbolt.org/

// to test
https://cppinsights.io/

// tuto GIT
https://learngitbranching.js.org/?locale=fr_FR

// Basic
BlitzMax

// Free License for resources
cc0

// Particle system editor
Pixel FX Editor

// Font Tool
FontLab

// Wool : have a look on it. Narrative tools ?

#endif