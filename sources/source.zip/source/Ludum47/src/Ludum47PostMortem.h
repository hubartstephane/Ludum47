#if 0


// Object : fixer weak_ptr/shared_ptr references circulaires
//
//
// CameraComponent : Conditionnal ApplyModifier => certains modifier devraient etre cosmetique da autre systematique
//
// Polygone -> PolyLine : creer une classe de base

// Polygone / Poyline . cela pourrait etre une surface, 
=> pas si evident car les points sont exprim�es relativement a la position de lobjet


//
// TMObject : un post Load ?
//
// for (auto ob : IterateByClass<TOTO>(my_array))
{
ca retourne un object avec begin()/end ++ 
ca fait auto_cast => + travail sur les pointeur weak_shared
et ca filtre par class
}
//

// ca serait bien que TMLevelInstance::Initialize puisse beneficier d un ReferenceSolver


// GameEntity : faire quelquechose de rotation . Notamment au niveau de PlayerStart


// TMObject/Particles => faire quelquechose de mieux



// on trouve "forced_tick_duratiocn" dans JSON, mais ce n'est pas utilis�


// la camera avec le zoom modifier ne semble pas rester dans le WORLD BOUNDING BOX


// faire en sorte que les particules puissent connaitre facilement (grace a l'allocation ??) le TMObjec a qui elles appartiennent
// LudumOpponent a montre ses limites


// PlayerPawn est un GameEntity.
// TMObject aussi.
//

mais PlayerPawn n'est pas referenc� dans TMLevelInstance ni aucun de ces layer



// Uniformiser la gestion des parametres JSON

->json dans TMObject::Initialize()
->json dans Player::Initialize()
->json dans SpecialClass


->Update en runtime les special classes ??




Fix WrapMode::Wrap avec float

Calcul du Mask de Collision ComputeLayerCollisionMask devrait etre dans TMLevel et pas TMLayerInstance => on ne derrive jamais TMLayerInstance (on devrait ??)

Revoir geometry de collision :

conversion automatic de box2 => obox ??


introduce     typename type_vec<T, dimension>      it does not exists !!!




gpd->IsButtonPressed(...) => gamepad peut connaitre la frame d avant
CheckKeyPressed(...) => le clavier ne peut pas connaire la frame d avant






deux fonctions => repetitions de code => on pourrait essayer d'unifier ca non ? 

void LudumPlayer::InternalHandleGamepadInputs(...)
void LudumPlayer::HandleKeyboardInputs()

Demande de touches generique manette/clavier


utiliser : int a = int(3); au lieu de ((int)a)



Creer un vrai particle spawner
qui s'attache a un layer
qui s'alloue un ParticleAllocation pour son propre usage
avec eventuellement des debit

genre

Pawn::Tick(dt)
{
	spawner->Tick(dt, [](SmokeParticleAccessor & accessor) 
	{
		le spawner decide combien de particule il va creer (avec un spawn rate),

			et on peut les initialiser ici

	})
}






On a un BeginParticleUpdate. On pourrait avoir un EndParticleUpdate()





#endif

