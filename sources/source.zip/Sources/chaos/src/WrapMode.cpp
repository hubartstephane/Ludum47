#include <chaos/WrapMode.h>
#include <chaos/JSONTools.h>

namespace chaos
{
	static std::vector<std::pair<WrapMode, char const*>> const wrapmode_encoding =
	{
		{ WrapMode::NONE, "NONE" },
		{ WrapMode::CLAMP, "CLAMP" },
		{ WrapMode::WRAP, "WRAP" },
		{ WrapMode::CHECK_RANGES, "CHECK_RANGES" }
	};

	CHAOS_IMPLEMENT_ENUMJSON_METHOD(WrapMode, wrapmode_encoding);

}; // namespace chaos