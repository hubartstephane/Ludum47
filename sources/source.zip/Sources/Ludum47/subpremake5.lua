-- =============================================================================
-- ROOT_PATH/executables/LUDUM/Ludum47
-- =============================================================================

  WindowedApp()
  DependOnLib("CHAOS")
  DependOnLib("DEATH")
  DeclareResource("resources")    
