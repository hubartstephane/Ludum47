#include <death/GameCheckpoint.h>

namespace death
{




}; // namespace death
